package acme.entities.tasks;

public enum Visibility {
	PRIVATE, PUBLIC

}
